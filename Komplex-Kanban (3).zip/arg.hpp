#include <complex.h>
{
  public:
  friend double arg (complex a);
}