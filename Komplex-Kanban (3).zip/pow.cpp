#include "complex.h"
#include <cmath>


complex pow(double b, const complex exp) {
  double ab = pow(b, exp.re);
  double ln = log(b);
  double cos = cos (complex.im * ln);

  double lnim = log(b);
  double sin = sin(exp.im * lnim);

  complex re = complex(cos, sin);
  return re;
}
complex pow(const complex b, int exp) {

}
complex pow(const complex b, double exp) {

}
complex pow(const complex b, const complex exp) {

}