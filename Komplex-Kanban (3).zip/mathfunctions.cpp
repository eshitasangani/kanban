#include <iostream>
#include <complex.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

/*
class MathFunctions{
  public: //List of all mathematical functions we need to include`
  double abs(const complex a){
    //math.abs(a.re);
  }
  double arg(const complex a);
  std::complex conj(const complex a);
  double imag(const complex& a);
  double norm(const complex a);
  std::complex polar(double mag, double ang=0.0);
  double real(const complex& a);
  std::complex acos(const complex a);
  std::complex asin(const complex a);
  std::complex atan(const complex a);
  std::complex cos(const complex a);


  
  std::complex cosh(const complex a);
  std::complex exp(const complex a);
  std::complex log(const complex a);
  std::complex log10(const complex a);
  std::complex pow(double b, const complex exp);
  std::complex pow(const complex b, int exp);
  std::complex pow(const complex b, double exp);
  std::complex pow(const complex b, const complex exp);
  std::complex sin(const complex a);
  std::complex sinh(const complex a);
  std::complex sqrt(const complex a);
  std::complex tan(const complex a);
  std::complex tanh(const complex a);
};*/