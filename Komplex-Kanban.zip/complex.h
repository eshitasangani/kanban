#include <iostream>


class complex {
 public:
  double re;
  double im;
 
 complex(){
  re = 0.0;
  im = 0.0;
 }
 complex(double r, double i) {
   re = r; 
   im = i;
 }

 
};