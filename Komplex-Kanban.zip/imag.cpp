#include <complex.h>

double imag(const complex& c) {
  return c.im;
}